# Worker validation — Pepe Premiere

Date: 2026-09-29. This is a worker's evidence record, not independent certification.

## Scope and consequential choices

Single React/TypeScript/Vite page; static export in `dist/`, no wallet/backend. Reviewed token loading, actual revealed and unrevealed metadata, three canvas motion styles, title editing, playback, PNG/MP4 export, source download, and instructions. Saved real #1 is labeled as a historical example. The immutable collection renderer supplies the artwork; studio effects never create traits. MP4 was selected instead of a browser-dependent WebM fallback. Public deployment consists of uploading the supplied `dist/` directory; no remote host credentials or URL were provided.

The pinned Better Interface workflow and core principles of all six domains were read before implementation. The document-web-design section was read before writing the final `DESIGN.md`. Their retained attribution is in `THIRD_PARTY.md`.

## Six-domain review

| Domain | Coverage | Evidence and limits |
| --- | --- | --- |
| Accessibility | Checked | Native form, labels, fieldset/radios, named canvas, DOM trait list, skip link, native named dialog, focus styling, alert/status regions; keyboard input/submit, arrow-radio selection, Escape/focus return and underlying-page focus blocking; reduced-motion and forced-colors emulation. axe: no violations in final tested states. No physical screen-reader or assistive-device session. |
| Layout | Checked | Actual production page at 1440×1100, 760×1100, 390×844, 320×800. Document scroll width equaled viewport width at all four. Editor, preview, errors, traits and dialog observed. Mobile preview anchor lands 16px below viewport top. Browser-native 200% zoom and physical devices unperformed. English-only; translated/RTL layouts not applicable to this implementation. |
| Writing | Checked | Actions match handlers; errors explain recovery and identify retained token. Saved/live and revealed/unrevealed states explicit. Export sizes, silence, duration and source-download behavior documented. No financial/rarity promises or invented traits. |
| Typography | Checked | Both local WOFF2 families loaded (`document.fonts.check` true); 16px inputs, hierarchy, wrapping and tabular counters reviewed in browser. Maximum-width 36-W title preserved as two 18-character lines per frame after the fix; blank title uses fallback. Supplemental card labels are intentionally small. |
| Colors | Checked | Rendered opaque foreground/background pairs measured using the WCAG relative-luminance formula. `contrast.json` records exact values. Field boundary repaired from 2.25:1 to 3.45:1; body/muted/action text pairs pass 4.5:1. Focus against page/editor/stage measures 5.92/6.51/5.36:1. Not every animated canvas/image/gradient pixel or hover/disabled pair was exhaustively measured. |
| UI | Checked | Source and browser review of selected, disabled, loading, invalid, network failure, missing token, unrevealed, export progress/cancel and success states. All three preview appearances and downloads exercised. Restrained six-second motion; no continuous redraw while paused. 10%-speed DevTools Animations-panel review unperformed (animation is canvas-driven). |

No dark theme, transaction flow, routing system, localization switcher or tooltip system was added simply for review coverage; those variants are not applicable.

## Findings, corrections and rechecks

Source locations below refer to the final, formatted source.

| Severity / owner | Source | Finding and correction | Recheck |
| --- | --- | --- | --- |
| HIGH / typography | `src/card.ts:109`, `src/card.ts:288` | Fixed-size title wrapping previously discarded lines after two, losing valid long titles. Renderer now decreases font size until all text fits two lines. | Browser canvas draw instrumentation: two 18-W lines per frame for 36-W input. Blank/custom titles also checked. |
| MEDIUM / layout | `src/card.ts:202`, `src/card.ts:236` | Glitch barcode occupied the title area; artwork-frame motion also left too little title clearance. Barcode moved to y=1620 and artwork frame center to y=855. | Viewed all three PNG compositions; all three MP4s exported and inspected through frame/codec checks. |
| HIGH / accessibility | `src/main.tsx:568` | Help dialog initially had no accessible name. Added `aria-labelledby` bound to its heading. | Named dialog, Escape and focus return observed; final dialog axe scan: no violations. |
| MEDIUM / accessibility | `src/main.tsx:345` | axe found a prohibited `aria-label` on the decorative loaded-state span. Removed the label and hid the redundant icon from AT. | Final editor axe scans: no violations. Visible loaded text carries the state. |
| MEDIUM / colors | `src/style.css:21` | Field boundary `#a9ae9d` on `#fffef9` measured 2.25:1. Darkened semantic field-border token to `#858c7b`. | Rendered pair 3.446:1, above 3:1 non-text threshold. |
| MEDIUM / writing/layout | `src/main.tsx:264`, `src/main.tsx:288` | Hiding the desktop line break joined “Pepe.Main” on mobile; preview was also far below editing controls. Added preserved word spacing and a mobile View preview anchor. | 390px screenshot shows word spacing; anchor scroll target verified at 16.42px. |
| LOW / UI | `src/main.tsx:147` | Paused preview kept scheduling canvas frames. Schedule recurring frames only while playing; redraw once for editing/fonts. | Reduced-motion startup has Play control; canvas data URL unchanged after 300ms. Editing still updates it. |
| LOW / accessibility/UI | `src/style.css:192` | Transform-only hidden skip link appeared in full-page captures above a scrolled viewport. Added opacity/pointer-state treatment while retaining keyboard focusability. | Final skip link appears on Tab and hides after focus moves; 320px error capture retaken. |

Native dialog Tab navigation can leave document focus for browser chrome (reported as BODY) before returning to the dialog. This is native browser behavior, not a focus trap on the underlying editor: an attempted focus on the token field while the modal was open was blocked, and Escape returned to How it works. No custom trapping implementation was added.

## Interaction and browser evidence

The supplied browser tool worked. The guide's suggested `test/scratch/browser/preview.json` was not present, and an initial guessed preview URL returned ERR_EMPTY_RESPONSE. A foreground Python HTTP server was instead run with an exec session on port 4175, serving a scratch `preview/` link to the actual `dist/`. This is local test infrastructure, not a public deployment. All inspections used `/preview/`; the server was stopped after checking.

Observed live browser reads:

- **#1:** exact original artwork, Light Green / Side Eye / Cigarette / None / Chain, with Ethereum source and pinned block.
- **#980:** real contract mystery SVG, “Unrevealed,” zero revealed trait rows, PNG export succeeds. Historical state can change; fixture provenance is in `docs/ONCHAIN.md`.
- **#5000:** real unminted revert produces an actionable error and retains #1.
- **0:** input error, focused token field, `aria-invalid`, still-visible prior card.
- A real Publicnode **429** was observed; dRPC fallback returned the requested artwork. Public RPC errors are external-service limitations, not suppressed test evidence.
- Both endpoints were deliberately aborted in a separate controlled test. Loading was disabled, failure was recoverable, and #1 remained visibly identified. This outage test was simulated, not an observed complete service outage.

Actual downloads: revealed PNGs in Spotlight, Orbit and Glitch; unrevealed PNG; MP4s for all three styles; source.zip. After cancellation, another export succeeded. Actual video generation in this environment took approximately 9.7s (Spotlight), 8.1s (Orbit), 5.1s (Glitch). Each MP4 has one H.264 Baseline video stream, yuv420p, 720×1280, 24/1 fps, 144 frames, duration 6.000000; no audio stream. Four PNGs are 1080×1920 RGB. See `export-checks.json` for hashes, bytes and actual ffprobe metadata. Media files remain scratch downloads, not unnecessary committed demo videos.

Source ZIP download was opened with Python zipfile: CRC integrity passed, required source/lockfile/fonts/license paths present, no node_modules or .git entries. The final publishing archive was regenerated after the documentation and evidence were complete.

The final clean browser reload plus PNG/source downloads generated **zero JavaScript console errors and zero failed requests**. Earlier 429 and deliberately aborted RPC requests are recorded above. All local static resources loaded from the `/preview/` subpath, including fonts, SVG, JSON, encoder and source archive.

Automated axe checks covered WCAG 2 A/AA, 2.1 AA and 2.2 AA tags. Final editor: 28 rules passed, zero violations; final dialog scan: 16 rules passed, zero violations. Incomplete color items concerned decorative logo/spark glyphs and an overlapping-surface heuristic for the Orbit label. The label was manually inspected and measured at 14.37:1 against its actual editor background; decorative non-text glyphs are hidden from AT. An axe pass is not a claim of complete accessibility compliance.

Screenshots were actually viewed before saving the delivered images:

- `studio-desktop.jpg`: 1440px, Spotlight, saved real example.
- `studio-760.jpg`: 760px intermediate two-column layout.
- `studio-mobile.jpg`: 390px, Orbit, edited title.
- `studio-320-error.jpg`: 320px, Glitch, invalid-ID state and focus.
- `help-mobile.jpg`: 390px native instructions dialog.

## Build and commands

Node 22.22.1, npm 9.2.0, TypeScript 5.8.3, Vite 6.4.3, React 19.1.0.

The initial toolchain was installed outside the repository at `/tmp/pepe-premiere-deps`; no dependency directory or ignore-file change was needed. Actual commands:

```sh
npm install --package-lock-only --ignore-scripts --cache /tmp/pepe-npm-cache
/tmp/pepe-premiere-deps/node_modules/.bin/tsc --noEmit -p test/scratch/tsconfig.json
NODE_PATH=/tmp/pepe-premiere-deps/node_modules node --test test/collection.test.mjs
/tmp/pepe-premiere-deps/node_modules/.bin/vite build --config test/scratch/vite.config.mjs
node scripts/package-source.mjs
```

All passed after repair: seven tests, zero failures; 32 modules in the production build. Scratch configs only map packages to the external worker install; ordinary source `vite.config.ts` and `tsconfig.json` have no temporary paths. Initial Vite 6.3.5 audit finding was resolved by pinning 6.4.3; npm reported zero vulnerabilities. An initial `vite/client` type-reference failure in the external resolver was repaired with explicit `*?url` typings. An initial Python image-check attempt found Pillow unavailable; actual downloaded media was checked with ffprobe instead. A Playwright attempt to click an intentionally visually hidden radio input timed out; corrected testing clicks its associated full label and separately verifies native ArrowRight selection. None of these unsuccessful checks are counted as passes.

Additional live Node reads exercised the real loader, and isolated accelerated timeout/cancellation tests verified both endpoint timeout and caller cancellation without contacting the fallback after abort. The seven committed tests cover real metadata fidelity, unrevealed suppression, ID validation, ABI bounds, active SVG rejection, block-pinned fallback, unminted errors and complete outage/abort behavior.

A fresh checkout was extracted from the actual source ZIP into `test/scratch/rebuild/pepe-premiere`. These documented commands all exited 0:

```sh
npm ci --ignore-scripts --cache /tmp/pepe-npm-cache --prefix test/scratch/rebuild/pepe-premiere
npm run typecheck --prefix test/scratch/rebuild/pepe-premiere
npm test --prefix test/scratch/rebuild/pepe-premiere
npm run build --prefix test/scratch/rebuild/pepe-premiere
```

Result: 23 installed packages, zero audit vulnerabilities, strict typecheck passed, 7/7 tests passed, Vite production build passed, public source ZIP created. Every exported file apart from the intentionally changing source ZIP was byte-identical to the root export that was inspected in the browser. This checks that no worker-only resolver, scratch file or removed input is needed for a normal rebuild.

The final source ZIP CRC, allowlist and per-file contents are checked again after evidence updates. Temporary `.playwright-mcp` recordings/downloads were removed. No ignore file was created or changed, no dependency/cache directory is submitted, and no `.git`, `.github` or `.env` file was edited. Required encoder, fonts, examples, complete source archive, lockfile and production export are retained.

## Remaining limitations

No native screen-reader session, browser-native 200% zoom, full localization/RTL suite, physical mobile hardware, Safari/Firefox/Edge session, actual Reels/TikTok upload, or remote deployment was performed. Public RPC uptime is not guaranteed. Unknown malformed metadata fails closed; after both endpoints fail parsing it currently reports the generic connection/retry error. No invented image/trait is used. The artwork remains the collection's property; studio-source licensing does not grant artwork rights.

## Completion

**Complete for the stated static implementation and publishing-deliverable scope.** All required production build, typecheck, useful interaction checks and six-domain review were performed, with the limitations above. `dist/` is ready for the contributor publisher and includes the publicly downloadable source. No external production URL or deployment is claimed. The conservative submission byte count is in `submission-size.json`; it excludes only platform inputs/metadata and the explicitly non-submitted `test/scratch/` area.
